# AnomalyDetection
## Code and Results

All the codes are written in `R`, and here is the instruction for getting the results in the example.pdf using the R file example.R


### Demo
First, put the 
```
require(knitr)
stitch("example.R")
```
and the result should look like example.pdf   
(This may take around 1 minutes on a typical laptop.)


